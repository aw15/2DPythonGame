from distutils.core import setup

setup(
    name='project',
    version='1.0.0',

    py_modules=['GUI ','Map','Mungi','Weather'],
    packages=[],
    url='www.naver.com',
    license='',
    author='Yang&Won',
    author_email='didxodbs@naver.com',
    description='bicycleApplication'
)
